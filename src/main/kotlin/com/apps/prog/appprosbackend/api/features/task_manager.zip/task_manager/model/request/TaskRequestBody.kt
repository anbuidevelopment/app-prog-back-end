package com.apps.prog.appprosbackend.api.features.task_manager.model.request

import com.apps.prog.appprosbackend.api.features.authentication.LmsUser
import com.apps.prog.appprosbackend.api.features.task_manager.model.Task

data class AssignTaskRequest(
    val task: Task,
    val lmsUser: LmsUser
)
