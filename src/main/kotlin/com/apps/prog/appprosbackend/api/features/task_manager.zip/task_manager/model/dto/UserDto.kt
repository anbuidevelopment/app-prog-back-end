package com.apps.prog.appprosbackend.api.features.task_manager.model.dto

data class UserDto(
    val id: Int,
    val fullName: String
)
